package com.jspiders.springcore.beans;

import lombok.Data;

@Data
public class EmployeeDetailsBean {

	private String email;

	private long phone;

	private double salary;

	private String address;

}
