package com.jspiders.springcore.beans;

import lombok.Data;

@Data
public class PlayerBean {

	private int id;

	private String name;

	private String role;

}
