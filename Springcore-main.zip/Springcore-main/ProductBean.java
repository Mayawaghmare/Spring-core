package com.jspiders.springcore.beans;

import lombok.Data;

@Data
public class ProductBean {

	private int id;

	private String name;

}
