package com.jspiders.springcore.beans;

import lombok.Data;

@Data
public class StudentBean {

	private int id;

	private String name;

	private String email;

}
